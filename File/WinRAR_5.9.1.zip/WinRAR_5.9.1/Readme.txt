  1. Install WinRAR v5.01.
  2. Now Right Click on "Crack.rar" and Choose "Extract Here". Password: 123
		- If you have trouble extracting crack.rar file then Make Sure to
			- Turn off All Options of Windows Defender Properly.
			- Turn off any other antivirus [if you have]
  3. Right Click on "Run-Crack.exe" and Choose "Run as Administrator".
  4. This keygen generates its keyfile in the user's profile "application 
     data" folder to be run without administrative rights.
     
     =================

[NOTE]: Make sure to ALWAYS Choose "Extract Here" option when Right Clicking all .rar files. Otherwise Installation will Fail.
		DONT Double Click RAR file and DONT open from Inside rar.
		ALWAYS RIGHT CLICK on rar file and Choose "Extract Here". [This is Important]
		If you still face any issue, Email us at contact@getintopc.com
		This Setup is 100% Tested and Working.
		
	=================
	
